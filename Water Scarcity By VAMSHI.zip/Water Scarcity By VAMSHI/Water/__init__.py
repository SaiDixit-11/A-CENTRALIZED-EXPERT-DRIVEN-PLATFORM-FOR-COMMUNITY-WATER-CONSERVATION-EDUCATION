import pymysql
# make PyMySQL act as MySQLdb for Django DB backends
pymysql.install_as_MySQLdb()