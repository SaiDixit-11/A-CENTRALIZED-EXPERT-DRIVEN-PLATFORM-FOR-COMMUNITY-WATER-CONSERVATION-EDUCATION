from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import os
import sqlite3
from datetime import date
import requests
import math
import json

# filesystem path to project's SQLite database
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'db.sqlite3')

def _ensure_tables() -> None:
    """Create legacy tables used by the original app (if they don't exist).

    - `register(username, password, contact, email, address)`
    - `techniques(name, technique, file, upload_date)`
    """
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS register (
            username TEXT PRIMARY KEY,
            password TEXT,
            contact TEXT,
            email TEXT,
            address TEXT
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS admin_register (
            username TEXT PRIMARY KEY,
            password TEXT,
            contact TEXT,
            email TEXT,
            address TEXT
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS techniques (
            name TEXT,
            technique TEXT,
            file TEXT,
            upload_date TEXT
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS user_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            request_type TEXT,
            details TEXT,
            status TEXT DEFAULT 'Pending',
            admin_comment TEXT DEFAULT 'None',
            request_date TEXT
        )
        """
    )
    conn.commit()
    conn.close()

# ensure tables exist at import time (safe, idempotent)
_ensure_tables()

uname = ""

def classify_groundwater(level_m_bgl: float) -> str:
    """Classify groundwater level (m below ground level).
    Lower depth = better availability.
    """
    if level_m_bgl <= 5:
        return "Excellent"
    if level_m_bgl <= 10:
        return "Good"
    if level_m_bgl <= 20:
        return "Moderate"
    return "Critical"


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return great-circle distance (kilometres) between two lat/lon points."""
    # convert degrees to radians
    rlat1, rlon1, rlat2, rlon2 = map(math.radians, (lat1, lon1, lat2, lon2))
    dlat = rlat2 - rlat1
    dlon = rlon2 - rlon1
    a = math.sin(dlat / 2) ** 2 + math.cos(rlat1) * math.cos(rlat2) * math.sin(dlon / 2) ** 2
    c = 2 * math.asin(min(1, math.sqrt(a)))
    return 6371.0 * c


def get_groundwater_api(request):
    """API endpoint: GET params `lat` and `lon` -> returns groundwater properties (JSON).
    Behavior:
    - best-effort attempt to query India‑WRIS (if reachable)
    - fallback to sample/mock data when WRIS is unavailable
    """
    if request.method != 'GET':
        return JsonResponse({'error': 'only GET allowed'}, status=405)

    lat = request.GET.get('lat')
    lon = request.GET.get('lon')
    try:
        lat_f = float(lat)
        lon_f = float(lon)
    except (TypeError, ValueError):
        return JsonResponse({'error': 'invalid or missing `lat`/`lon`'}, status=400)

    # sample (provided) — return when user clicks near this point
    sample = {
        "state": "Telangana",
        "district": "Medak",
        "block": "Narsapur",
        "latitude": 17.702,
        "longitude": 78.107,
        "gw_level_m_bgl": 9.8,
        "season": "Pre-Monsoon",
        "year": 2024,
    }

    if _haversine_km(lat_f, lon_f, sample['latitude'], sample['longitude']) <= 20.0:
        sample['classification'] = classify_groundwater(sample['gw_level_m_bgl'])
        sample['source'] = 'sample'
        return JsonResponse(sample)

    # Try live India-WRIS endpoint (best-effort). If WRIS is unreachable or returns unexpected data,
    # fall back to a synthesized result.
    try:
        api_url = "https://indiawris.gov.in/wris/api/gw/gw_level"
        resp = requests.get(api_url, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        # Attempt to find nearest station in returned list (if API returns list-like payload)
        if isinstance(data, list):
            best = None
            best_d = float('inf')
            for item in data:
                try:
                    lat2 = float(item.get('latitude') or item.get('lat') or item.get('Lattitude') or 0)
                    lon2 = float(item.get('longitude') or item.get('lon') or item.get('Longitude') or 0)
                    gw = float(item.get('gw_level_m_bgl') or item.get('gw_level') or item.get('gw') or 0)
                except Exception:
                    continue
                d = _haversine_km(lat_f, lon_f, lat2, lon2)
                if d < best_d:
                    best_d = d
                    best = (item, d)
            if best and best[1] <= 50.0:
                item = best[0]
                gw_val = float(item.get('gw_level_m_bgl') or item.get('gw_level') or item.get('gw') or 0)
                result = {
                    'state': item.get('state') or '',
                    'district': item.get('district') or '',
                    'block': item.get('block') or '',
                    'latitude': float(item.get('latitude') or item.get('lat') or 0),
                    'longitude': float(item.get('longitude') or item.get('lon') or 0),
                    'gw_level_m_bgl': gw_val,
                    'season': item.get('season') or '',
                    'year': int(item.get('year') or 0),
                    'classification': classify_groundwater(gw_val),
                    'source': 'indiawris'
                }
                return JsonResponse(result)
    except Exception:
        # best-effort; ignore and fall through to fallback
        pass

    # Fallback synthesized response (when WRIS not available)
    mock_level = 12.3
    fallback = {
        'state': 'Unknown',
        'district': 'Unknown',
        'block': 'Unknown',
        'latitude': lat_f,
        'longitude': lon_f,
        'gw_level_m_bgl': mock_level,
        'season': 'Unknown',
        'year': 2024,
        'classification': classify_groundwater(mock_level),
        'source': 'fallback'
    }
    return JsonResponse(fallback)


def Logout(request):
    """Clear global session variable and redirect to index."""
    global uname
    uname = ""
    return render(request, "index.html", {"data": "Logged out successfully"})


def Videos(request):
    if request.method == 'GET':
        return render(request, 'Videos.html', {})

def Download(request):
    if request.method == 'GET':
        global fileList
        name = request.GET.get('requester', False)
        with open("WaterApp/static/files/"+name, "rb") as file:
            data = file.read()
        file.close()        
        response = HttpResponse(data,content_type='application/force-download')
        response['Content-Disposition'] = 'attachment; filename='+name
        return response   

def AccessAdvice(request):
    if request.method == 'GET':
        global uname
        output = '<table border=1 align=center width=100%><tr><th><font size="3" color="black">Expert Name</th><th><font size="3" color="black">Water Saving Techniques & Ideas</th>'
        output+='<th><font size="3" color="black">Post Date</th><th><font size="3" color="black">Download Tools/Videos on Water Saving</th></tr>'
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        with con:    
            cur = con.cursor()
            cur.execute("select * FROM techniques")
            rows = cur.fetchall()
            for row in rows:
                name = row[0]
                technique = row[1]
                file = row[2]
                upload_date = row[3]
                output += '<tr><td><font size="3" color="black">'+str(name)+'</td><td><font size="3" color="black">'+str(technique)+'</td>'
                output+='<td><font size="3" color="black">'+upload_date+'</td>'
                output +='<td><a href=\'Download?requester='+file+'\'><font size=3 color=black>Download</font></a></td></tr>'
        output += "</table><br/><br/><br/><br/>"    
        
        # Get requests for Dashboard context
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM user_requests WHERE username = ?", (uname,))
        requests_list = cur.fetchall()
        
        return render(request, 'UserScreen.html', {'data': output, 'username': uname, 'requests': requests_list})    

def AccessMap(request):
    if request.method == 'GET':
        areaname = "Rajasthan"
        areaname = areaname+" most drought areas"
        areaname = areaname.replace(" ","+")
        output = '<iframe width="800" height="650" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q='+areaname+'&amp;ie=UTF8&amp;&amp;output=embed"></iframe><br/>'
        
        # Get requests for Dashboard context
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM user_requests WHERE username = ?", (uname,))
        requests_list = cur.fetchall()
        
        return render(request, 'UserScreen.html', {'data': output, 'username': uname, 'requests': requests_list})

OPENROUTER_API_KEY = "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"
OPENROUTER_MODEL = "arcee-ai/trinity-large-preview:free"

def get_xai_response(prompt):
    """Query OpenRouter API with reasoning enabled."""
    try:
        url = "https://openrouter.ai/api/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000", # Optional, for OpenRouter rankings
            "X-Title": "HydroLearn WaterScarcity", # Optional
        }
        payload = {
            "model": OPENROUTER_MODEL,
            "messages": [{"role": "user", "content": prompt}],
            "reasoning": {"enabled": True}
        }
        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=30)
        response.raise_for_status()
        res_json = response.json()
        
        # OpenRouter usually returns content in choices[0].message.content
        msg = res_json.get('choices', [{}])[0].get('message', {})
        content = msg.get('content', '')
        
        # If model used reasoning, content might be prefixed or separate depending on model.
        # arcee-ai/trinity-large-preview:free provides content directly.
        if not content:
            return "Intelligence Offline: The model returned an empty response. Please retry."
            
        return content
    except Exception as e:
        return f"OpenRouter Insight unavailable: {str(e)}"

def ShareKnowledgeAction(request):
    if request.method == 'POST':
        global uname
        ideas = request.POST.get('t1', False)
        ideas = ideas.replace("'", "")
        myfile = request.FILES['t2'].read()
        fname = request.FILES['t2'].name
        dd = str(date.today())
        
        # XAI Logic: Get conservation insight from Gemini
        ai_prompt = f"Analyze this water saving technique: '{ideas}'. Provide a brief expert validation and one potential improvement (XAI Insight)."
        xai_result = get_xai_response(ai_prompt)

        db_connection = sqlite3.connect(DB_PATH)
        db_connection.row_factory = sqlite3.Row
        db_cursor = db_connection.cursor()
        db_cursor.execute(
            "INSERT INTO techniques (name, technique, file, upload_date) VALUES (?, ?, ?, ?)",
            (uname, ideas, fname, dd),
        )
        db_connection.commit()
        
        if not os.path.exists("WaterApp/static/files/"):
            os.makedirs("WaterApp/static/files/")
            
        with open("WaterApp/static/files/"+fname, "wb") as file:
            file.write(myfile)
        
        status_msg = f"<div class='success-msg'>Your technique was shared! <br/><br/><strong>XAI Logic Analysis:</strong><p>{xai_result}</p></div>"
        context = {'data': status_msg}
        return render(request, 'ShareKnowledge.html', context)

def ShareKnowledge(request):
    if request.method == 'GET':
       return render(request, 'ShareKnowledge.html', {})

import folium
import webbrowser

def AccessMap(request):
    if request.method == 'GET':
        return render(request, 'AccessMap.html', {})

def AnalyzeLocation(request):
    loc = request.GET.get('loc', 'Jaipur')
    
    # Geocoding Cache (Fast fallbacks to save API quota)
    locations = {
        'jaipur': [26.9124, 75.7873],
        'jodhpur': [26.2389, 73.0243],
        'udaipur': [24.5854, 73.7125],
        'hyderabad': [17.3850, 78.4867],
        'bengaluru': [12.9716, 77.5946],
        'bangalore': [12.9716, 77.5946],
        'delhi': [28.6139, 77.2090],
        'mumbai': [19.0760, 72.8777],
        'chennai': [13.0827, 80.2707],
        'kolkata': [22.5726, 88.3639],
        'pune': [18.5204, 73.8567],
        'ahmedabad': [23.0225, 72.5714],
        'new york': [40.7128, -74.0060],
        'london': [51.5074, -0.1278],
        'paris': [48.8566, 2.3522],
        'tokyo': [35.6762, 139.6503],
    }

    # Support Coordinate Search or Dynamic AI Geocoding
    if "," in loc and any(char.isdigit() for char in loc):
        try:
            parts = loc.split(",")
            lat = float(parts[0].strip())
            lon = float(parts[1].strip())
            coords = [lat, lon]
        except (ValueError, IndexError):
            coords = locations.get(loc.lower(), None)
    else:
        coords = locations.get(loc.lower(), None)

    # Dynamic AI Geocoding Fallback
    if not coords:
        try:
            geo_prompt = f"Return ONLY the Latitude and Longitude of '{loc}' as a comma-separated string (e.g. 12.97, 77.59). If the location is imaginary, return 20.5937, 78.9629. No other text."
            geo_res = get_xai_response(geo_prompt)
            # Clean AI response for robust parsing
            clean_geo = geo_res.replace("lat:", "").replace("lon:", "").replace(" ", "").strip()
            parts = clean_geo.split(",")
            lat = float(parts[0])
            lon = float(parts[1])
            coords = [lat, lon]
        except (ValueError, IndexError, Exception):
            coords = [20.5937, 78.9629] # Default to India center
    
    lat, lon = coords
    
    # Gemini AI Analysis + Dynamic Weather
    ai_prompt = (
        f"The location is {loc} with coordinates {lat}, {lon}. "
        "Provide current approximate weather data and water scarcity analysis.\n"
        "Format your answer EXACTLY as follows:\n"
        "WEATHER: [Temperature in C],[Humidity in %],[Climate Condition]\n"
        "ANALYSIS: [Detailed Drought Statistics and Conservation Outlook]"
    )
    ai_raw = get_xai_response(ai_prompt)
    
    # Parse AI response for dynamic values
    temp, hum, cond = "29.0", "40", "Humid" # Fallbacks
    ai_analysis = ai_raw
    
    if "WEATHER:" in ai_raw and "ANALYSIS:" in ai_raw:
        try:
            parts = ai_raw.split("ANALYSIS:")
            weather_part = parts[0].replace("WEATHER:", "").strip()
            ai_analysis = parts[1].strip()
            
            w_parts = weather_part.split(",")
            if len(w_parts) >= 3:
                temp = w_parts[0].strip().replace("°C", "").replace("C", "").strip()
                hum = w_parts[1].strip().replace("%", "").strip()
                cond = w_parts[2].strip()
        except Exception:
            pass # Keep fallbacks
            
    weather_data = {
        'temp': temp,
        'humidity': hum,
        'condition': cond
    }

    # Folium Map Generation - Save to static for Iframe access
    m = folium.Map(location=[lat, lon], zoom_start=12)
    popup_text = f"<b>{loc}</b><br/>{ai_analysis[:300]}..."
    folium.Marker([lat, lon], popup=folium.Popup(popup_text, max_width=300)).add_to(m)
    
    # Ensure nested static directory exists
    static_map_dir = os.path.join("WaterApp", "static", "maps")
    if not os.path.exists(static_map_dir):
        os.makedirs(static_map_dir)
        
    map_filename = f"map_{loc.lower()}.html"
    file_path = os.path.join(static_map_dir, map_filename)
    m.save(file_path)
    
    return JsonResponse({
        'lat': lat,
        'lon': lon,
        'weather': weather_data,
        'ai_analysis': ai_analysis,
        'map_url': f"/static/maps/{map_filename}"
    })

def ShareKnowledge(request):
    if request.method == 'GET':
        return render(request, 'ShareKnowledge.html', {})

def UserLogin(request):
    if request.method == 'GET':
        return render(request, 'UserLogin.html', {})

def index(request):
    if request.method == 'GET':
        return render(request, 'index.html', {})

def Signup(request):
    if request.method == 'GET':
        return render(request, 'Signup.html', {})

def UserLoginAction(request):
    if request.method == 'POST':
        global uname
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        with con:
            cur = con.cursor()
            cur.execute("SELECT password FROM register WHERE username = ?", (username,))
            row = cur.fetchone()
            if row and row[0] == password:
                uname = username
                return UserScreen(request)
        return render(request, "UserLogin.html", {'data': "Invalid login"})
    return render(request, "UserLogin.html", {})

def UserScreen(request):
    global uname
    if not uname:
        return render(request, "UserLogin.html", {"data": "Please login first"})
    
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM user_requests WHERE username = ?", (uname,))
    requests_list = cur.fetchall()
    
    return render(request, 'UserScreen.html', {'requests': requests_list, 'username': uname})

def SubmitRequest(request):
    global uname
    if request.method == 'POST':
        rtype = request.POST.get('rtype', '')
        
        # Aggregate all dynamic fields into details
        form_data = []
        for key, value in request.POST.items():
            if key not in ['csrfmiddlewaretoken', 'rtype', 'details'] and value:
                # Format key for readability (e.g. delivery_address -> Delivery Address)
                label = key.replace('_', ' ').title()
                form_data.append(f"{label}: {value}")
        
        # Add the main details textarea content
        extra_details = request.POST.get('details', '')
        if extra_details:
            form_data.append(f"Notes: {extra_details}")
            
        details_summary = " | ".join(form_data)
        dd = str(date.today())
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("INSERT INTO user_requests (username, request_type, details, request_date) VALUES (?, ?, ?, ?)", (uname, rtype, details_summary, dd))
            con.commit()
        return UserScreen(request)

def UserForms(request):
    ftype = request.GET.get('type', '1')
    titles = {
        '1': 'Water Supply Request',
        '2': 'Conservation Grant Application',
        '3': 'Leakage Reporting Form',
        '4': 'Volunteer Registration',
        '5': 'Water Audit Request'
    }
    return render(request, 'UserForms.html', {'title': titles.get(ftype, 'Form'), 'type': ftype})

def ManageRequests(request):
    global uname
    if not uname:
        return render(request, "AdminLogin.html", {"data": "Please login first"})
    
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT * FROM user_requests")
    rows = cur.fetchall()
    return render(request, 'ManageRequests.html', {'requests': rows})

def ActionOnRequest(request):
    if request.method == 'POST':
        rid = request.POST.get('id')
        status = request.POST.get('status')
        comment = request.POST.get('comment')
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("UPDATE user_requests SET status=?, admin_comment=? WHERE id=?", (status, comment, rid))
            con.commit()
        return ManageRequests(request)

def DeleteRequest(request):
    global uname
    if not uname:
        return render(request, "index.html", {"data": "Session expired. Please login."})
    
    rid = request.GET.get('id')
    con = sqlite3.connect(DB_PATH)
    with con:
        cur = con.cursor()
        cur.execute("SELECT username FROM user_requests WHERE id = ?", (rid,))
        row = cur.fetchone()
        
        cur.execute("SELECT 1 FROM admin_register WHERE username = ?", (uname,))
        is_admin = cur.fetchone()
        
        if row:
            request_owner = row[0]
            if is_admin or request_owner == uname:
                cur.execute("DELETE FROM user_requests WHERE id = ?", (rid,))
                con.commit()
    
    cur = con.cursor()
    cur.execute("SELECT 1 FROM admin_register WHERE username = ?", (uname,))
    if cur.fetchone():
        return ManageRequests(request)
    else:
        return UserScreen(request)

def SignupAction(request):
    if request.method == 'POST':
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        contact = request.POST.get('t3', False)
        email = request.POST.get('t4', False)
        address = request.POST.get('t5', False)
        output = "none"
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        with con:
            cur = con.cursor()
            cur.execute("SELECT 1 FROM register WHERE username = ?", (username,))
            if cur.fetchone():
                output = username+" Username already exists"
        if output == 'none':
            db_connection = sqlite3.connect(DB_PATH)
            db_connection.row_factory = sqlite3.Row
            db_cursor = db_connection.cursor()
            db_cursor.execute(
                "INSERT INTO register (username, password, contact, email, address) VALUES (?, ?, ?, ?, ?)",
                (username, password, contact, email, address),
            )
            db_connection.commit()
            print(db_cursor.rowcount, "Record Inserted")
            if db_cursor.rowcount == 1:
                output = 'Signup Process Completed'
        context= {'data':output}
        return render(request, 'Signup.html', context)

def AdminSignup(request):
    if request.method == 'GET':
       return render(request, 'AdminSignup.html', {})

def AdminSignupAction(request):
    if request.method == 'POST':
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        contact = request.POST.get('t3', False)
        email = request.POST.get('t4', False)
        address = request.POST.get('t5', False)
        output = "none"
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        with con:
            cur = con.cursor()
            cur.execute("SELECT 1 FROM admin_register WHERE username = ?", (username,))
            if cur.fetchone():
                output = username+" Admin Username already exists"
        if output == 'none':
            db_connection = sqlite3.connect(DB_PATH)
            db_connection.row_factory = sqlite3.Row
            db_cursor = db_connection.cursor()
            db_cursor.execute(
                "INSERT INTO admin_register (username, password, contact, email, address) VALUES (?, ?, ?, ?, ?)",
                (username, password, contact, email, address),
            )
            db_connection.commit()
            if db_cursor.rowcount == 1:
                output = 'Admin Signup Process Completed'
        context= {'data':output}
        return render(request, 'AdminSignup.html', context)

def AdminLogin(request):
    if request.method == 'GET':
       return render(request, 'AdminLogin.html', {})

def AdminLoginAction(request):
    if request.method == 'POST':
        global uname
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        page = "AdminLogin.html"
        status = "Invalid admin login"
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        with con:
            cur = con.cursor()
            cur.execute("SELECT password FROM admin_register WHERE username = ?", (username,))
            row = cur.fetchone()
            if row and row[0] == password:
                uname = username
                status = "Welcome Admin "+username
                page = "AdminScreen.html"
        context= {'data': status}
        return render(request, page, context)

def UpdateUserProfile(request):
    global uname
    if request.method == 'GET':
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM register WHERE username = ?", (uname,))
        row = cur.fetchone()
        return render(request, 'UpdateUserProfile.html', {'user': row})
    elif request.method == 'POST':
        password = request.POST.get('t1', False)
        contact = request.POST.get('t2', False)
        email = request.POST.get('t3', False)
        address = request.POST.get('t4', False)
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("UPDATE register SET password=?, contact=?, email=?, address=? WHERE username=?", (password, contact, email, address, uname))
            con.commit()
        return render(request, 'UserScreen.html', {'data': 'Profile updated successfully'})

def UpdateAdminProfile(request):
    global uname
    if request.method == 'GET':
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM admin_register WHERE username = ?", (uname,))
        row = cur.fetchone()
        return render(request, 'UpdateAdminProfile.html', {'user': row})
    elif request.method == 'POST':
        password = request.POST.get('t1', False)
        contact = request.POST.get('t2', False)
        email = request.POST.get('t3', False)
        address = request.POST.get('t4', False)
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("UPDATE admin_register SET password=?, contact=?, email=?, address=? WHERE username=?", (password, contact, email, address, uname))
            con.commit()
        return render(request, 'AdminScreen.html', {'data': 'Admin Profile updated successfully'})

def ManageUsers(request):
    if request.method == 'GET':
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT * FROM register")
        rows = cur.fetchall()
        return render(request, 'ManageUsers.html', {'users': rows})

def DeleteUser(request):
    if request.method == 'GET':
        username = request.GET.get('username')
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("DELETE FROM register WHERE username = ?", (username,))
            con.commit()
        return ManageUsers(request)

def ManageTechniques(request):
    if request.method == 'GET':
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT rowid, * FROM techniques")
        rows = cur.fetchall()
        return render(request, 'ManageTechniques.html', {'techniques': rows})

def DeleteTechnique(request):
    if request.method == 'GET':
        rowid = request.GET.get('id')
        con = sqlite3.connect(DB_PATH)
        with con:
            cur = con.cursor()
            cur.execute("DELETE FROM techniques WHERE rowid = ?", (rowid,))
            con.commit()
        return ManageTechniques(request)

def AdminScreen(request):
    global uname
    if not uname:
        return render(request, "AdminLogin.html", {"data": "Please login first"})
    
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT COUNT(*) FROM register")
    user_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM techniques")
    tech_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM user_requests WHERE status = 'Pending'")
    pending_req_count = cur.fetchone()[0]
    
    return render(request, 'AdminScreen.html', {
        'user_count': user_count,
        'tech_count': tech_count,
        'pending_req_count': pending_req_count,
        'username': uname
    })
      
