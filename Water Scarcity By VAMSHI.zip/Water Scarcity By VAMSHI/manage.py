#!/usr/bin/env python
import os
import sys

# enforce Python 3.12+ for this repository
if sys.version_info < (3, 12):
    sys.stderr.write("This project requires Python 3.12 or newer.\n")
    sys.exit(1)

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "Water.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
